<button type="button" class="btn btn-primary addService">
    <?php echo e(__('Add Service')); ?>

</button>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/services/service/components/add-button.blade.php ENDPATH**/ ?>