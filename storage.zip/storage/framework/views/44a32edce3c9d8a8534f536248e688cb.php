<div id="editCategoryModal" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h2><?php echo e(__('messages.category.edit_category')); ?></h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>

            </div>
            <?php echo e(Form::open(['id'=>'editCategoryForm'])); ?>

            <div class="modal-body scroll-y">
                <div class="alert alert-danger display-none hide" id="editValidationErrorsBox"></div>
                <?php echo e(Form::hidden('categoryId',null,['id'=>'editModalCategoryId'])); ?>

                <div class="row">
                    <div class="form-group col-sm-12 mb-5">
                        <?php echo e(Form::label('name',__('messages.common.name').':', ['class' => 'form-label required mb-3'])); ?>

                        <?php echo e(Form::text('name', null, ['id'=>'editCategoryName','class' => 'form-control ','required','placeholder' => __('messages.common.name')])); ?>

                    </div>
                </div>
            </div>
            <div class="modal-footer pt-0">
                <?php echo e(Form::button(__('messages.common.save'), ['type' => 'submit','class' => 'btn btn-primary me-2','id' => 'btnEditSave','data-loading-text' => "<span class='spinner-border spinner-border-sm'></span> Processing..."])); ?>

                <button type="button" class="btn btn-secondary btn-active-light-primary me-3"
                        data-bs-dismiss="modal"><?php echo e(__('messages.common.cancel')); ?></button>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/services/service/service_edit_modal.blade.php ENDPATH**/ ?>