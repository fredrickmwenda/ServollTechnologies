<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.taxes')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex flex-column ">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tax-table', [])->html();
} elseif ($_instance->childHasBeenRendered('LcBZM25')) {
    $componentId = $_instance->getRenderedChildComponentId('LcBZM25');
    $componentTag = $_instance->getRenderedChildComponentTagName('LcBZM25');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LcBZM25');
} else {
    $response = \Livewire\Livewire::mount('tax-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('LcBZM25', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <?php echo $__env->make('taxes.create_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('taxes.edit_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/taxes/index.blade.php ENDPATH**/ ?>