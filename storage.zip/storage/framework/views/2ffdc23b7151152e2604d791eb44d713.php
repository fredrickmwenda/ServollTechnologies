<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
    <li class="nav-item <?php echo e(Request::is('admin/dashboard*','admin/currency-reports*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('admin.dashboard')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fa-chart-pie pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.dashboard')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/users*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('users.index')); ?>">
            <span class="menu-icon">
                <i class="fas fa-user-alt pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.admins')); ?></span>
        </a>
    </li>

   

    <li class="nav-item <?php echo e(Request::is('admin/client*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('clients.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-users pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.clients')); ?></span>
        </a>
    </li>
 <!-- Additional Blog -->
    <li class="nav-item <?php echo e(Request::is('admin/categories*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('blogs.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-th-list pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('Blogs')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/categories*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('blogs.blogCategories.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-th-list pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('Blog Categories')); ?></span>
        </a>
    </li>


    <li class="nav-item <?php echo e(Request::is('admin/categories*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('tags.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-th-list pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('Tags')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/services*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('services.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-th-list pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e('Services'); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/taxes*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('taxes.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-percentage pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.taxes')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/products*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('products.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-cube pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.products')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/quotes*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('quotes.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-quote-left pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.quotes')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/invoices*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('invoices.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid far fa-file-alt pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.invoices')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/payment-qr-codes*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page"
            href="<?php echo e(route('payment-qr-codes.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fa-qrcode pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo __('messages.payment_qr_codes.payment_qr_codes'); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/transactions*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('transactions.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-list-ol pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.transactions')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/payments*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('payments.index')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fas fa-money-check pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.payments')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(Request::is('admin/template-setting*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('invoiceTemplate')); ?>">
            <span class="menu-icon">
                <i class="fa-solid far fa-copy pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.invoice_templates')); ?></span>
        </a>
    </li>

    <li
        class="nav-item <?php echo e(Request::is('admin/settings*', 'admin/currencies*', 'admin/payment-gateway*', 'admin/invoice-settings*') ? 'active' : ''); ?>">
        <a class="nav-link d-flex align-items-center py-3" aria-current="page" href="<?php echo e(route('settings.edit')); ?>">
            <span class="menu-icon">
                <i class="fa-solid fa fa-cogs pe-3"></i>
            </span>
            <span class="aside-menu-title"><?php echo e(__('messages.settings')); ?></span>
        </a>
    </li>
<?php endif; ?>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'client')): ?>
    <?php echo $__env->make('client_panel.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/layouts/menu.blade.php ENDPATH**/ ?>