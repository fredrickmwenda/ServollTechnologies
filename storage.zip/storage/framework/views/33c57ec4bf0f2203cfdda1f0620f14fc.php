<button type="button" class="btn btn-primary addTag">
    <?php echo e(__('Add Tag')); ?>

</button>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/tags/components/add-button.blade.php ENDPATH**/ ?>