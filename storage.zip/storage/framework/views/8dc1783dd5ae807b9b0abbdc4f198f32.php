<div id="addTagModal" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h2><?php echo e(__('Add Tag')); ?></h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
            </div>
            <!-- 'files' = true -->
            <?php echo e(Form::open(['id'=>'addTagForm', 'files' => true])); ?>

                <div class="modal-body scroll-y">
                    <div class="alert alert-danger display-none hide" id="editValidationErrorsBox"></div>
                    <div class="row">
                        <div class="form-group col-sm-12 mb-5">
                            <?php echo e(Form::label('name',__('Tag Name').':', ['class' => 'form-label required mb-3'])); ?>

                            <?php echo e(Form::text('name','name',['id'=>'name','class' => 'form-control  '])); ?>

                        </div>

                    </div>

                </div>
                <div class="modal-footer pt-0">
                    <?php echo e(Form::button(__('Add Tag'), ['type' => 'submit','class' => 'btn btn-primary me-2','id' => 'btnAddTag','data-loading-text' => "<span class='spinner-border spinner-border-sm'></span> Processing...", 'data-new-text' => __('messages.common.pay')])); ?>

                    <button type="button" class="btn btn-secondary btn-active-light-primary me-3"
                            data-bs-dismiss="modal"><?php echo e(__('messages.common.cancel')); ?></button>
                </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>


 <?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/tags/modal.blade.php ENDPATH**/ ?>