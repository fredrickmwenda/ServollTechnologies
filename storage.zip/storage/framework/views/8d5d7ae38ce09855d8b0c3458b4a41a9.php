<?php $__env->startSection('title'); ?>
<?php echo e(__('Tags')); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex flex-column ">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tag-table', [])->html();
} elseif ($_instance->childHasBeenRendered('IKxDJIq')) {
    $componentId = $_instance->getRenderedChildComponentId('IKxDJIq');
    $componentTag = $_instance->getRenderedChildComponentTagName('IKxDJIq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IKxDJIq');
} else {
    $response = \Livewire\Livewire::mount('tag-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('IKxDJIq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php echo $__env->make('tags.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tags.edit_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    listenClick(".addTag", (function() {
            $("#addTagModal").appendTo("body").modal("show")
        })),
        listenSubmit("#addTagForm", (
            function(e) {
                e.preventDefault(),
                    formData = new FormData(this);
                for (var pair of formData.entries()) {
                    console.log(pair[0] + ', ' + pair[1]);
                };
                $.ajax({
                    url: route("tags.store"),
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(e) {
                        e.success && ($("#addTagModal").modal("hide"),
                            displaySuccessMessage(e.message),
                            livewire.emit("refreshDatatable"),
                            livewire.emit("resetPageTable"))
                    },
                    error: function(e) {
                        displayErrorMessage(e.responseJSON.message)
                    }
                })
            })),
        listenHiddenBsModal(
            "#addTagModal", (
                function() {
                    resetModalForm("#addTagForm", "#validationErrorsBox")
                }
            )
        ),
        $("#btnAddTag").addClass("disabled");
    $("#error-msg").text("");
    $("#btnAddTag").removeClass("disabled");

</script>
<script> 
listenClick('.tag-delete-btn', function (event) {
    let recordId = $(event.currentTarget).attr('data-id');
    deleteItem(route('tags.delete', recordId))
        // Lang.get('messages.client.client'));
})

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/tags/index.blade.php ENDPATH**/ ?>