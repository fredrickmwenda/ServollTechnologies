<a type="button" class="btn btn-primary" href="<?php echo e(route('blogs.create')); ?>">
    <?php echo e(__('Add Blog')); ?>

</a><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/bloging/blog/components/add-button.blade.php ENDPATH**/ ?>