<a type="button" class="btn btn-primary" href="<?php echo e(route('products.create')); ?>">
    <?php echo e(__('messages.product.add_product')); ?>

</a>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/products/components/add-button.blade.php ENDPATH**/ ?>