<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.clients')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex flex-column  ">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('client-table', [])->html();
} elseif ($_instance->childHasBeenRendered('VRtFif0')) {
    $componentId = $_instance->getRenderedChildComponentId('VRtFif0');
    $componentTag = $_instance->getRenderedChildComponentTagName('VRtFif0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VRtFif0');
} else {
    $response = \Livewire\Livewire::mount('client-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('VRtFif0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/clients/index.blade.php ENDPATH**/ ?>