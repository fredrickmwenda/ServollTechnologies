    
    <?php $__env->startSection('title'); ?>
        <?php echo e(__('messages.dashboard')); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <div class="d-flex flex-column">
                <div class="row">
                    <div class="col-12">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('clients.index')); ?>" class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-primary shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-between my-3">
                                        <div
                                            class="bg-cyan-300 widget-icon rounded-10 d-flex align-items-center justify-content-center">
                                            <i class="fas fa-user display-4 card-icon text-white"></i>
                                        </div>
                                        <div class="text-end text-white">
                                            <h2 class="fs-1-xxl fw-bolder text-white">
                                                <?php echo e(formatTotalAmount($total_clients)); ?></h2>
                                            <h3 class="mb-0 fs-4 fw-light">
                                                <?php echo e(__('messages.admin_dashboard.total_clients')); ?></h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('currency.reports')); ?>" class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-success shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-center my-3">
                                        <div class="text-white mt-3 text-center">
                                            <h2 class="fs-1-xxl fw-bolder text-white">
                                                <?php echo e(__('messages.admin_dashboard.total_amount')); ?>

                                            </h2>
                                            <span class="text-white"><?php echo e(__('messages.common.click_here')); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('currency.reports')); ?>" class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-info shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-center my-3">
                                        <div class="text-white mt-3 text-center">
                                            <h2 class="fs-1-xxl fw-bolder text-white">
                                                <?php echo e(__('messages.admin_dashboard.total_paid')); ?>

                                            </h2>
                                            <span class="text-white"><?php echo e(__('messages.common.click_here')); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('currency.reports')); ?>" class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-warning shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-center my-3">
                                        <div class="text-white mt-3 text-center">
                                            <h2 class="fs-1-xxl fw-bolder text-white">
                                                <?php echo e(__('messages.admin_dashboard.total_due')); ?>

                                            </h2>
                                            <span class="text-white"><?php echo e(__('messages.common.click_here')); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('products.index')); ?>" class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-secondary shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-between my-3">
                                        <div
                                            class="bg-gray-300 widget-icon rounded-10 d-flex align-items-center justify-content-center">
                                            <i class="fas fa-cube display-4 card-icon text-dark"></i>
                                        </div>
                                        <div class="text-end text-dark">
                                            <h2 class="fs-1-xxl fw-bolder text-dark">
                                                <?php echo e(formatTotalAmount($total_products)); ?></h2>
                                            <h3 class="mb-0 fs-4 fw-light">
                                                <?php echo e(__('messages.admin_dashboard.total_products')); ?></h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('invoices.index')); ?>" class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-danger shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-between my-3">
                                        <div
                                            class="bg-red-300 widget-icon rounded-10 d-flex align-items-center justify-content-center">
                                            <i class="fas fa-file-invoice display-4 card-icon text-white"></i>
                                        </div>
                                        <div class="text-end text-white">
                                            <h2 class="fs-1-xxl fw-bolder text-white">
                                                <?php echo e(formatTotalAmount($total_invoices)); ?></h2>
                                            <h3 class="mb-0 fs-4 fw-light">
                                                <?php echo e(__('messages.admin_dashboard.total_invoices')); ?></h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('invoices.index', ['status' => 2])); ?>"
                                    class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-dark shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-between my-3">
                                        <div
                                            class="bg-gray-300 widget-icon rounded-10 d-flex align-items-center justify-content-center">
                                            <i
                                                class="fas fa-clipboard-check display-4 card-icon <?php echo e(\Illuminate\Support\Facades\Auth::user()->dark_mode ? 'text-black' : 'text-white'); ?>"></i>
                                        </div>
                                        <div
                                            class="text-end <?php echo e(\Illuminate\Support\Facades\Auth::user()->dark_mode ? 'text-black' : 'text-white'); ?>">
                                            <h2
                                                class="fs-1-xxl fw-bolder <?php echo e(\Illuminate\Support\Facades\Auth::user()->dark_mode ? 'text-black' : 'text-white'); ?>">
                                                <?php echo e(formatTotalAmount($paid_invoices)); ?></h2>
                                            <h3 class="mb-0 fs-4 fw-light">
                                                <?php echo e(__('messages.admin_dashboard.total_paid_invoices')); ?></h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xxl-3 col-xl-4 col-sm-6 widget">
                                <a href="<?php echo e(route('invoices.index', ['status' => 1])); ?>"
                                    class="mb-xl-8 text-decoration-none">
                                    <div
                                        class="bg-primary shadow-md rounded-10 p-xxl-10 px-7 py-10 d-flex align-items-center justify-content-between my-3">
                                        <div
                                            class="bg-cyan-300 widget-icon rounded-10 d-flex align-items-center justify-content-center">
                                            <i class="fas fa-exclamation-triangle display-4 card-icon text-white"></i>
                                        </div>
                                        <div class="text-end text-white">
                                            <h2 class="fs-1-xxl fw-bolder text-white">
                                                <?php echo e(formatTotalAmount($unpaid_invoices)); ?></h2>
                                            <h3 class="mb-0 fs-4 fw-light">
                                                <?php echo e(__('messages.admin_dashboard.total_unpaid_invoices')); ?></h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mb-4">
                        <div class="">
                            <div class="card mt-3">
                                <div class="card-body p-5">
                                    <div class="card-header border-0 pt-5">
                                        <h3 class="mb-0"><?php echo e(__('messages.admin_dashboard.income_overview')); ?></h3>
                                        <div class="ms-auto">
                                            <div id="rightData" class="date-picker-space">
                                                <input class="form-control " id="time_range">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body p-lg-6 p-0">
                                        <div class="">
                                            <div id="yearly_income_overview-container" class="pt-2">
                                                <canvas id="yearly_income_chart_canvas" height="200"
                                                    width="905"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-6 col-12 mb-5 mb-xl-0">
                        <div class="card">
                            <div class="card-header pb-0 px-10">
                                <h3 class="mb-0"><?php echo e(__('messages.admin_dashboard.payment_overview')); ?></h3>
                            </div>
                            <div class="card-body pt-7">
                                <div id="payment-overview-container" class="justify-align-center">
                                    <canvas id="payment_overview"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-6 col-12">
                        <div class="card">
                            <div class="card-header pb-0 px-10">
                                <h3 class="mb-0"><?php echo e(__('messages.admin_dashboard.invoice_overview')); ?></h3>
                            </div>
                            <div class="card-body pt-7">
                                <div id="invoice-overview-container" class="justify-align-center">
                                    <canvas id="invoice_overview"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo e(Form::hidden('currency', getCurrencySymbol(), ['id' => 'currency'])); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/dashboard/index.blade.php ENDPATH**/ ?>