<footer class="border-top w-100 pt-4 mt-7">
    <div class="d-flex justify-content-between">
        <p class="fs-6 text-gray-600">All Rights Reserved ©<?php echo e(\Carbon\Carbon::now()->year); ?>

            <a href="<?php echo e(url('/')); ?>" class="text-decoration-none"><?php echo e(getAppName()); ?></a>
        </p>
        <?php if(\Illuminate\Support\Facades\Auth::user()->hasRole('admin')): ?>
        <div>v<?php echo e(getCurrentVersion()); ?></div>
        <?php endif; ?>
    </div>
</footer>

<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/layouts/footer.blade.php ENDPATH**/ ?>