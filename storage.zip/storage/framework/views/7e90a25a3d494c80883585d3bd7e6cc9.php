<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.products')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex flex-column ">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-table', [])->html();
} elseif ($_instance->childHasBeenRendered('2Ojj7v4')) {
    $componentId = $_instance->getRenderedChildComponentId('2Ojj7v4');
    $componentTag = $_instance->getRenderedChildComponentTagName('2Ojj7v4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2Ojj7v4');
} else {
    $response = \Livewire\Livewire::mount('product-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('2Ojj7v4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <?php echo e(Form::hidden('currency', getCurrencySymbol(),['id' => 'currency'])); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/products/index.blade.php ENDPATH**/ ?>