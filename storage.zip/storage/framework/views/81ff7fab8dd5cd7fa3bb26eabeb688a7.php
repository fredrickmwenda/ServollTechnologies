<button type="button" class="btn btn-primary addTax">
    <?php echo e(__('messages.tax.add_tax')); ?>

</button>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/taxes/components/add-button.blade.php ENDPATH**/ ?>