<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.categories')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex flex-column ">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog-category-table', [])->html();
} elseif ($_instance->childHasBeenRendered('uqRpHMu')) {
    $componentId = $_instance->getRenderedChildComponentId('uqRpHMu');
    $componentTag = $_instance->getRenderedChildComponentTagName('uqRpHMu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uqRpHMu');
} else {
    $response = \Livewire\Livewire::mount('blog-category-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('uqRpHMu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <?php echo $__env->make('bloging.blogCategory.create_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('bloging.blogCategory.edit_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script> 
listenClick(".addBlogCategory",(function(){$("#addBlogCategoryModal").appendTo("body").modal("show")})),
listenSubmit("#addBlogCategoryForm",(
    
    function(e){
        e.preventDefault(),
        formData = new FormData(this);
        for (var pair of formData.entries()) {
        console.log(pair[0]+ ', '+ pair[1]); 
    }
      ;
        $.ajax({
            url:route("blogs.blogCategories.store"),
            type:"POST",
            data:formData,
            processData:false,
            contentType:false, 
            success:function(e){
                e.success&&($("#addBlogCategoryModal").modal("hide"),
                displaySuccessMessage(e.message),
                livewire.emit("refreshDatatable"),
                livewire.emit("resetPageTable"))
            },
            error:function(e){
                displayErrorMessage(e.responseJSON.message)
            }
        })
    })
),
listenHiddenBsModal(
    "#addBlogCategoryModal",(
        function(){
            resetModalForm("#addBlogCategoryForm","#validationErrorsBox")
        }
    )
),
$("#btnAddService").addClass("disabled");
$("#error-msg").text("");
$("#btnAddService").removeClass("disabled");
</script>


<script> 
listenClick('.blog-category-delete-btn', function (event) {
    let recordId = $(event.currentTarget).attr('data-id');
    deleteItem(route('tags.delete', recordId))
        // Lang.get('messages.client.client'));
})

</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/bloging/blogCategory/index.blade.php ENDPATH**/ ?>