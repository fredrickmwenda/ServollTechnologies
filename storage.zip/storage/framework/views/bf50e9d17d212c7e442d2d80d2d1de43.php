<a type="button" class="btn btn-primary" href="<?php echo e(route('clients.create')); ?>">
    <?php echo e(__('messages.client.add_client')); ?>

</a>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/clients/components/add-button.blade.php ENDPATH**/ ?>