<button type="button" class="btn btn-primary addBlogCategory">
    <?php echo e(__('Add Category')); ?>

</button>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/bloging/blogCategory/components/add-button.blade.php ENDPATH**/ ?>