
<?php $__env->startPush('css'); ?>
<style>
  .comment__item {
    overflow: auto;
    box-sizing: border-box;

  }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- Livewire scripts -->

<!-- ========================
       page title 
    =========================== -->
<section class="page-title2  text-center bg-overlay">
  <!-- <div class="container">
    <div class="row align-items-center">
      <div class="col-12">

      </div>
    </div>
  
  </div> -->
</section>

<!-- ======================
      Blog Single
    ========================= -->
<section class="blog blog-single pt-5 pb-70">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-8">
        <div class="post-item mb-0">
          <!-- /blog-img -->
          <div class="post__img">
            <a href="#">
              <img src="<?php echo e(asset($blog->banner)); ?>" alt="blog image">
            </a>
          </div>
          <!-- /blog-content -->
          <div class="post__content">
            <div class="post__meta d-inline-flex flex-wrap align-items-center mb-0">
              <span class="post__meta-author">
                <img src="<?php echo e(asset('assets/smart/images/blog/author/1.jpg')); ?>" alt="author">
                <span class="color-secondary">By:</span>
                <a href="#" class="color-body">
                  <?php if($blog->author): ?>
                  <?php echo e($blog->author->first_name ?? ''); ?> <?php echo e($blog->author->last_name ?? ''); ?>

                  <?php else: ?>
                  Fredrick Mwenda
                  <?php endif; ?>
                </a>
              </span>
              <div class="post__meta-cat">
                <?php $__currentLoopData = $blog->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- capitalize the first letter -->
                <a href="#"><?php echo e(ucfirst($tag->name)); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div><!-- /.blog-meta-cat -->
              <span class="post__meta-date"><?php echo e($blog->created_at->format('M d, Y')); ?></span>
            </div><!-- /.blog-meta -->
            <h1 class="post__title"><?php echo e($blog->title); ?></h1>
            <div class="post__desc"><?php echo e($blog->description); ?></div><!-- /.blog-desc -->
          </div>
        </div><!-- /.post-item -->
        <div class="bordered-box mb-30">
          <div class="row row-no-gutter ">
            <div class="col-sm-12 col-md-6 col-lg-6 d-flex justify-content-center">
              <div class="blog-share d-flex flex-wrap">
                <strong class="mr-20 color-heading">Share</strong>
                <ul class="list-unstyled social-icons social-icons-primary d-flex mb-0">
                  <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fab fa-google"></i></a></li>
                </ul>
              </div><!-- /.blog-share -->
            </div>
            <div class="col-sm-12 col-md-6 col-lg-6 d-flex justify-content-center">
              <div class="blog-tags d-flex flex-wrap">
                <strong class="mr-20 color-heading">Tags</strong>
                <ul class="list-unstyled d-flex flex-wrap mb-0">
                  <?php $__currentLoopData = $blog->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <!-- capitalize the first letter -->
                  <li><a href="#"><?php echo e(ucfirst($tag->name)); ?></a></li>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
              </div><!-- /.blog-tags -->
            </div>
          </div>
        </div>
        <div class="widget-nav d-flex justify-content-between mb-40">
          <a href="<?php echo e(route('single_blog', $previousPost->id)); ?>" class="widget-nav__prev d-flex flex-wrap">
            <div class="widget-nav__img">
              <div class="widget-nav__overlay"></div>
              <img src="<?php echo e(asset($previousPost->thumbnail_image)); ?>" alt="blog thumb">
            </div>
            <div class="widget-nav__content">
              <span>Previous Post</span>
              <h5 class="fz-16 mb-0"><?php echo e($previousPost->title); ?></h5>
            </div>
          </a><!-- /.blog-prev  -->
          <a href="<?php echo e(route('single_blog', $nextPost->id)); ?>" class="widget-nav__next d-flex flex-wrap">
            <div class="widget-nav__img">
              <div class="widget-nav__overlay"></div>
              <img src="<?php echo e(asset($nextPost->thumbnail_image)); ?>" alt="blog thumb">
            </div>
            <div class="widget-nav__content">
              <span>Next Post</span>
              <h5 class="fz-16 mb-0"><?php echo e($nextPost->title); ?></h5>
            </div>
          </a><!-- /.blog-next  -->
        </div>


        <?php if($comments->isNotEmpty()): ?>
        <div class="blog-comments mb-40">
          <h5 class="blog-widget__title"><?php echo e(count($comments)); ?> comments</h5>
          <ul class="comments-list list-unstyled">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="comment__item">
              <!-- Display comment details -->
              <div class="comment__avatar">
                <img src="<?php echo e(asset('assets/smart/images/blog/author/2.jpg')); ?>" alt="avatar">
              </div>
              <div class="comment__content">
                <!-- Display commenter's name or user's name -->
                <h5 class="comment__author"><?php echo e($comment->user_id ? $comment->user->name : $comment->name); ?></h5>
                <span class="comment__date"><?php echo e($comment->created_at->format('M d, Y - h:i A')); ?></span>
                <p class="comment__desc"><?php echo e($comment->content); ?></p>
                <!-- Reply link to show/hide reply form -->
                <a class="comment__reply" href="#" onclick="toggleReplyForm('<?php echo e($comment->id); ?>')">reply</a>
              </div>

              <!-- Reply form -->
              <div id="replyForm_<?php echo e($comment->id); ?>" style="display: none;">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment-form', ['parentId' => $comment->id, 'blogId' => $blog->id])->html();
} elseif ($_instance->childHasBeenRendered('s6f1p8B')) {
    $componentId = $_instance->getRenderedChildComponentId('s6f1p8B');
    $componentTag = $_instance->getRenderedChildComponentTagName('s6f1p8B');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('s6f1p8B');
} else {
    $response = \Livewire\Livewire::mount('comment-form', ['parentId' => $comment->id, 'blogId' => $blog->id]);
    $html = $response->html();
    $_instance->logRenderedChild('s6f1p8B', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              </div>

              <!-- Nested replies -->
              <?php if(count($comment->replies) > 0): ?>
              <ul class="nested__comment list-unstyled">
                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="comment__item">
                  <div class="comment__avatar">
                    <img src="<?php echo e(asset('assets/smart/images/blog/author/3.jpg')); ?>" alt="avatar">
                  </div>
                  <div class="comment__content">
                    <?php if(empty($reply->user_id)): ?>
                    <h5 class="comment__author"><?php echo e($reply->name); ?></h5>
                    <?php else: ?>
                    <h5 class="comment__author"><?php echo e($reply->user->name); ?></h5>
                    <?php endif; ?>
                    <span class="comment__date"><?php echo e($reply->created_at->format('M d, Y - h:i A')); ?></span>
                    <p class="comment__desc"><?php echo e($reply->content); ?></p>
                    <a class="comment__reply" href="#" onclick="toggleReplyForm('<?php echo e($reply->id); ?>')">reply</a>
                  </div>

                  <!-- Nested reply form -->
                  <div id="replyForm_<?php echo e($reply->id); ?>" style="display: none;">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment-form', ['parentId' => $reply->id, 'blogId' => $blog->id])->html();
} elseif ($_instance->childHasBeenRendered('2p8XJQo')) {
    $componentId = $_instance->getRenderedChildComponentId('2p8XJQo');
    $componentTag = $_instance->getRenderedChildComponentTagName('2p8XJQo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2p8XJQo');
} else {
    $response = \Livewire\Livewire::mount('comment-form', ['parentId' => $reply->id, 'blogId' => $blog->id]);
    $html = $response->html();
    $_instance->logRenderedChild('2p8XJQo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                  </div>

                  <!-- Nested replies -->
                  <?php if(count($reply->replies) > 0): ?>
                  <ul class="nested__comment list-unstyled">
                    <?php $__currentLoopData = $reply->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nestedReply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="comment__item">
                      <!-- Nested reply details -->
                      <div class="comment__avatar">
                        <img src="<?php echo e(asset('assets/smart/images/blog/author/3.jpg')); ?>" alt="avatar">
                      </div>
                      <div class="comment__content">
                        <?php if(empty($nestedReply->user_id)): ?>
                        <h5 class="comment__author"><?php echo e($nestedReply->name); ?></h5>
                        <?php else: ?>
                        <h5 class="comment__author"><?php echo e($nestedReply->user->name); ?></h5>
                        <?php endif; ?>
                        <span class="comment__date"><?php echo e($nestedReply->created_at->format('M d, Y - h:i A')); ?></span>
                        <p class="comment__desc"><?php echo e($nestedReply->content); ?></p>
                        <a class="comment__reply" href="#" onclick="toggleReplyForm('<?php echo e($nestedReply->id); ?>')">reply</a>
                      </div>

                      <!-- Nested reply form -->
                      <div id="replyForm_<?php echo e($nestedReply->id); ?>" style="display: none;">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment-form', ['parentId' => $nestedReply->id, 'blogId' => $blog->id])->html();
} elseif ($_instance->childHasBeenRendered('iYggtbt')) {
    $componentId = $_instance->getRenderedChildComponentId('iYggtbt');
    $componentTag = $_instance->getRenderedChildComponentTagName('iYggtbt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iYggtbt');
} else {
    $response = \Livewire\Livewire::mount('comment-form', ['parentId' => $nestedReply->id, 'blogId' => $blog->id]);
    $html = $response->html();
    $_instance->logRenderedChild('iYggtbt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                      </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                  <?php endif; ?>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <?php endif; ?>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>
      <?php else: ?>
      <div class="blog-comments-form mb-40">
        <h5 class="blog-widget__title">Leave A Reply</h5>
        <!-- Display comment form for new comment -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment-form', ['parentId' => null, 'blogId' => $blog->id])->html();
} elseif ($_instance->childHasBeenRendered('oNLT0Qn')) {
    $componentId = $_instance->getRenderedChildComponentId('oNLT0Qn');
    $componentTag = $_instance->getRenderedChildComponentTagName('oNLT0Qn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oNLT0Qn');
} else {
    $response = \Livewire\Livewire::mount('comment-form', ['parentId' => null, 'blogId' => $blog->id]);
    $html = $response->html();
    $_instance->logRenderedChild('oNLT0Qn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
      </div>
      <?php endif; ?>










      <!-- /.blog-comments-form -->

      <div class="col-sm-12 col-md-12 col-lg-4">
        <aside class="sidebar">
          <div class="widget widget-search">
            <h5 class="widget__title">Search</h5>
            <div class="widget__content">
              <form class="widget__form-search">
                <input type="text" class="form-control" placeholder="Search...">
                <button class="btn" type="submit"><i class="icon-search"></i></button>
              </form>
            </div><!-- /.widget-content -->
          </div><!-- /.widget-search -->
          <div class="widget widget-posts">
            <h5 class="widget__title">Recent Posts</h5>
            <div class="widget__content">
              <!-- post item #1 -->
              <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="widget-post-item d-flex align-items-center">
                <div class="widget-post__img">
                  <a href="#"><img src="<?php echo e(asset($recentBlog->thumbnail_image)); ?>" alt="thumb"></a>
                </div><!-- /.widget-post-img -->
                <div class="widget-post__content">
                  <h4 class="widget-post__title"><a href="<?php echo e(route('single_blog', $blog->id)); ?>"><?php echo e($recentBlog->title); ?></a></h4>
                  <span class="widget-post__date"><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('M d, Y')); ?></span>

                </div><!-- /.widget-post-content -->
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <!-- /.widget-post-item -->
              <!-- post item #2 -->

            </div><!-- /.widget-content -->
          </div><!-- /.widget-posts -->
          <div class="widget widget-categories">
            <h5 class="widget__title">Categories</h5>
            <div class="widget-content">
              <ul class="list-unstyled">
                <?php $__currentLoopData = $categoriesWithCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#"><span><?php echo e($category->name); ?></span><span class="cat-count"><?php echo e($category->blogs_count); ?></span></a></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </ul>
            </div><!-- /.widget-content -->
          </div><!-- /.widget-categories -->
          <div class="widget widget-tags">
            <h5 class="widget__title">Tags</h5>
            <div class="widget-content">
              <ul class="list-unstyled d-flex flex-wrap">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#"><?php echo e($tag->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </ul>
            </div><!-- /.widget-content -->
          </div><!-- /.widget-tags -->
        </aside><!-- /.sidebar -->
      </div><!-- /.col-lg-4 -->
    </div><!-- /.row -->
  </div><!-- /.container -->
</section><!-- /.blog Single -->




<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
  document.addEventListener('livewire:load', function() {
    Livewire.on('commentAdded', function() {
      // Refresh comments section
      Livewire.emit('refreshComments');
    });
  });
</script>

<script>
  function toggleReplyForm(commentId) {

    var replyForm = document.getElementById('replyForm_' + commentId);
    if (replyForm.style.display === "none") {
      replyForm.style.display = "block";
    } else {
      replyForm.style.display = "none";
    }
  }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/front/blog-single-post.blade.php ENDPATH**/ ?>