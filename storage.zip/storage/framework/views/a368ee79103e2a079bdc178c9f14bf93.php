<div class="d-flex justify-content-center">
    <?php if(isset($value['show-route'])): ?>
        <a href="javascript:void(0)" data-id="<?php echo e($dataId); ?>" title="Show" data-bs-toggle="tooltip"
            class="<?php echo e($value['data-show-id']); ?> btn px-2 text-info fs-3 py-2" data-bs-toggle="tooltip">
            <i class="fas fa-eye"></i>
        </a>
    <?php endif; ?>
    <a title="<?php echo e(__('messages.common.edit')); ?>" data-id="<?php echo e($dataId); ?>" data-bs-toggle="tooltip"
        class="edit-btn btn px-2 text-primary fs-3 py-2 <?php echo e($editClass ?? ''); ?>">
        <i class="fa-solid fa-pen-to-square"></i>
    </a>

    <a title="<?php echo e(__('messages.common.delete')); ?>" href="javascript:void(0)" data-bs-toggle="tooltip"
        data-id="<?php echo e($dataId); ?>" class="btn px-2 text-danger fs-3 py-2 <?php echo e($deleteClass ?? ''); ?>">
        <i class="fa-solid fa-trash"></i>
    </a>
</div>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/livewire/modal-action-button.blade.php ENDPATH**/ ?>