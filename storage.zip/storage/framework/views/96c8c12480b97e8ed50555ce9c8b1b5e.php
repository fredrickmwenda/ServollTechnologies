<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.blogs')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex flex-column  ">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog-table', [])->html();
} elseif ($_instance->childHasBeenRendered('I5ttTgI')) {
    $componentId = $_instance->getRenderedChildComponentId('I5ttTgI');
    $componentTag = $_instance->getRenderedChildComponentTagName('I5ttTgI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('I5ttTgI');
} else {
    $response = \Livewire\Livewire::mount('blog-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('I5ttTgI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/bloging/blog/index.blade.php ENDPATH**/ ?>