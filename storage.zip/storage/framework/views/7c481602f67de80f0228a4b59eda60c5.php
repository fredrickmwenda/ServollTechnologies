<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('*/dashboard*', '*/currency-reports*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('*/dashboard*') ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?>

        </a>
    </li>
<?php endif; ?>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'client')): ?>
    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('*/dashboard*', '*/currency-reports*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('*/dashboard*') ? 'active' : ''); ?>"
            href="<?php echo e(route('client.dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?>

        </a>
    </li>
<?php endif; ?>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('*/dashboard*', '*/currency-reports*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('*/currency-reports*') ? 'active' : ''); ?>"
            href="<?php echo e(route('currency.reports')); ?>"><?php echo e(__('messages.currency_reports')); ?>

        </a>
    </li>
<?php endif; ?>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'client')): ?>
    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('*/dashboard*', '*/currency-reports*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('*/currency-reports*') ? 'active' : ''); ?>"
            href="<?php echo e(route('client.currency.reports')); ?>"><?php echo e(__('messages.currency_reports')); ?>

        </a>
    </li>
<?php endif; ?>
<li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/users*') ? 'd-none' : ''); ?>">
    <a class="nav-link p-0 <?php echo e(Request::is('admin/users*') ? 'active' : ''); ?>"
        href="<?php echo e(route('users.index')); ?>"><?php echo e(__('messages.admins')); ?></a>
</li>
<li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/clients*') ? 'd-none' : ''); ?>">
    <a class="nav-link p-0 <?php echo e(Request::is('admin/clients*') ? 'active' : ''); ?>"
        href="<?php echo e(route('clients.index')); ?>"><?php echo e(__('messages.clients')); ?></a>
</li>
<li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/categories*') ? 'd-none' : ''); ?>">
    <a class="nav-link p-0 <?php echo e(Request::is('admin/categories*') ? 'active' : ''); ?>"
        href="<?php echo e(route('category.index')); ?>"><?php echo e(__('messages.categories')); ?></a>
</li>
<li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/taxes*') ? 'd-none' : ''); ?>">
    <a class="nav-link p-0 <?php echo e(Request::is('admin/taxes*') ? 'active' : ''); ?>"
        href="<?php echo e(route('taxes.index')); ?>"><?php echo e(__('messages.taxes')); ?></a>
</li>
<li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/products*') ? 'd-none' : ''); ?>">
    <a class="nav-link p-0 <?php echo e(Request::is('admin/products*') ? 'active' : ''); ?>"
        href="<?php echo e(route('products.index')); ?>"><?php echo e(__('messages.products')); ?></a>
</li>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
    <li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/transactions*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('admin/transactions*') ? 'active' : ''); ?>"
            href="<?php echo e(route('transactions.index')); ?>"><?php echo e(__('messages.transactions')); ?></a>
    </li>
<?php else: ?>
    <li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('client/transactions*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('client/transactions*') ? 'active' : ''); ?>"
            href="<?php echo e(route('client.transactions.index')); ?>"><?php echo e(__('messages.transactions')); ?></a>
    </li>
<?php endif; ?>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/payment-qr-codes*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('admin/payment-qr-codes*') ? 'active' : ''); ?>"
            href="<?php echo e(route('payment-qr-codes.index')); ?>"><?php echo e(__('messages.payment_qr_codes.payment_qr_codes')); ?></a>
    </li>
<?php endif; ?>
<li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('*/quotes*') ? 'd-none' : ''); ?>">
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
        <a class="nav-link p-0 <?php echo e(Request::is('*/quotes*') ? 'active' : ''); ?>"
            href="<?php echo e(route('quotes.index')); ?>"><?php echo e(__('messages.quotes')); ?></a>
    <?php endif; ?>
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'client')): ?>
        <a class="nav-link p-0 <?php echo e(Request::is('*/quotes*') ? 'active' : ''); ?>"
            href="<?php echo e(route('client.quotes.index')); ?>"><?php echo e(__('messages.quotes')); ?></a>
    <?php endif; ?>
</li>
<li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('*/invoices*') ? 'd-none' : ''); ?>">
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
        <a class="nav-link p-0 <?php echo e(Request::is('*/invoices*') ? 'active' : ''); ?>"
            href="<?php echo e(route('invoices.index')); ?>"><?php echo e(__('messages.invoices')); ?></a>
    <?php endif; ?>
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'client')): ?>
        <a class="nav-link p-0 <?php echo e(Request::is('*/invoices*') ? 'active' : ''); ?>"
            href="<?php echo e(route('client.invoices.index')); ?>"><?php echo e(__('messages.invoices')); ?></a>
    <?php endif; ?>
</li>
<li
    class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/template-setting*') ? 'd-none' : ''); ?>">
    <a class="nav-link p-0 <?php echo e(Request::is('admin/template-setting*') ? 'active' : ''); ?>"
        href="<?php echo e(route('invoiceTemplate')); ?>"><?php echo e(__('messages.invoice_templates')); ?></a>
</li>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
    <li class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/payments*') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('admin/payments*') ? 'active' : ''); ?>"
            href="<?php echo e(route('payments.index')); ?>"><?php echo e(__('messages.payments')); ?></a>
    </li>
<?php endif; ?>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
    
    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/settings*', 'admin/currencies*', 'admin/payment-gateway*', 'admin/invoice-settings') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(isset($sectionName) ? ($sectionName == 'general' ? 'active' : '') : ''); ?>"
            href="<?php echo e(route('settings.edit', ['section' => 'general'])); ?>"><?php echo e(__('messages.general')); ?></a>
    </li>

    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/settings*', 'admin/currencies*', 'admin/payment-gateway*', 'admin/invoice-settings') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('admin/currencies*') ? 'active' : ''); ?>"
            href="<?php echo e(route('currencies.index')); ?>"><?php echo e(__('messages.setting.currencies')); ?></a>
    </li>

    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/settings*', 'admin/currencies*', 'admin/payment-gateway*', 'admin/invoice-settings') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('admin/payment-gateway*') ? 'active' : ''); ?>"
            href="<?php echo e(route('payment-gateway.show', ['section' => 'payment-gateway'])); ?>"><?php echo e(__('messages.payment-gateway')); ?></a>
    </li>

    <li
        class="nav-item position-relative mx-xl-3 mb-3 mb-xl-0 <?php echo e(!Request::is('admin/settings*', 'admin/currencies*', 'admin/payment-gateway*', 'admin/invoice-settings') ? 'd-none' : ''); ?>">
        <a class="nav-link p-0 <?php echo e(Request::is('admin/invoice-settings*') ? 'active' : ''); ?>"
            href="<?php echo e(route('settings.invoice-settings')); ?>"><?php echo e(__('messages.setting.invoice_settings')); ?></a>
    </li>
<?php endif; ?>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/layouts/sub_menu.blade.php ENDPATH**/ ?>