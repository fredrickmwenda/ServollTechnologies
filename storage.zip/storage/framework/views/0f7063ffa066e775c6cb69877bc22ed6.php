<div class="aside-menu-container" id="sidebar">
    <div class="aside-menu-container__aside-logo flex-column-auto">
        <a href="<?php echo e(url('/')); ?>" class="text-decoration-none sidebar-logo d-flex align-items-center" data-bs-toggle="tooltip"
           title="<?php echo e((strlen(getAppName()) > 15 ) ? substr(getAppName(), 0,15).'...' : getAppName()); ?>">
            <div class="image image-mini me-3">
                <img src="<?php echo e(getLogoUrl()); ?>"
                     class="img-fluid object-contain" alt="profile image">
            </div>
            <span class="text-gray-900 fs-4"><?php echo e((strlen(getAppName()) > 15 ) ? substr(getAppName(), 0,15).'...' : getAppName()); ?></span>
        </a>
        <button type="button" class="btn px-0 aside-menu-container__aside-menubar d-lg-block d-none sidebar-btn">
            <i class="fa-solid fa-bars fs-1"></i>
        </button>
    </div>
    <div class="aside-menu-container__sidebar-scrolling overflow-auto">
        <ul class="aside-menu-container__aside-menu nav flex-column">
            <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
    </div>
</div>
<div class="bg-overlay" id="sidebar-overly"></div>
<?php /**PATH /home/basamiy/Documents/Projects/invoices/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>