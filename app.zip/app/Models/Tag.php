<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $table = 'tags';
    

    public function blogs()
    {
        return $this->belongsToMany(Blog::class, 'blog_tag');
    }
}
